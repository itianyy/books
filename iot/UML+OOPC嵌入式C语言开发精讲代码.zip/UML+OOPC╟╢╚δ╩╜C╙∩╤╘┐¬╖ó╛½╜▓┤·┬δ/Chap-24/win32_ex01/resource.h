//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by win32_ex01.rc
//
#define IDC_MYICON                      2
#define IDD_WIN32_EX01_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WIN32_EX01                  107
#define IDI_SMALL                       108
#define IDC_WIN32_EX01                  109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP2                     130
#define IDB_BUTTON1                     200
#define IDB_BUTTON2                     201
#define IDM_CLEAR_AND_BEGIN             300
#define IDM_STOP                        301
#define IDM_STOP_AND_DRAW               302
#define CM_RED                          400
#define CM_BLACK                        401
#define CM_BLUE                         402
#define CM_GREEN                        403
#define ID_FILE_SAVE                    500
#define ID_FILE_LOAD                    501
#define ID_FILE_LOAD_FROM_FILE          509
#define ID_FILE_CLEAR                   502
#define ID_FILE_SAVE32771               32771
#define ID_FILE_LOAD32772               32772
#define ID_FILE_CLEAR32773              32773
#define ID_FILE_LOADFROMFILE            32774
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
