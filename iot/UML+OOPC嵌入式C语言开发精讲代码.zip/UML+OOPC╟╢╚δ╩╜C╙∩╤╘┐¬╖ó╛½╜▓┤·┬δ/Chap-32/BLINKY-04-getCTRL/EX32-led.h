/* EX32-led.h   */
#include "lw_oopc_kc.h"
#include "ex32-il.h"

CLASS(LED_P0)
{
	IMPLEMENTS(IL);
};

CLASS(LED_P1)
{
	IMPLEMENTS(IL);
};