/* ex16-int.h */ 

CLASS(Integer)
{
  IMPLEMENTS(IDisplay);
  int value;
};

