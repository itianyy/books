/*  EX16-il.h */ 
#ifndef _IL_H
#define _IL_H
#include "lw_oopc_kc.h"

INTERFACE(IL)
{
    int (*pass)(char, char, void*);
};
#endif


