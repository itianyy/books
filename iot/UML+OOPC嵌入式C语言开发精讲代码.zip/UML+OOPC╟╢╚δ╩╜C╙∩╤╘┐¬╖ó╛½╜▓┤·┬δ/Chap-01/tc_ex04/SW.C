/* SW.c   */
#include "stdio.h"

void swDown()
   {  printf("SW is Down\n");  }
void swUp()
   {  printf("SW is Up\n");  }


