/* EX27-10.C (BLINKY.C)  */
#include <REG51F.H>
#include "lw_oopc_kc.h"
/* ����LED�� */
CLASS(LED)
{
   void (*run)();     /* ����LED����ĺ��� */
};

void wait (void)  {              
       ;                              
     }

/* ʵ��LED�����run()���� */
	static void run(){
    unsigned int i;   unsigned char j;      
    for (j=0x01; j< 0x80; j<<=1)  {   
       P1 = j;                         
       for (i = 0; i < 10000; i++)  {  
           wait ();                      
       }
    }
    for (j=0x80; j> 0x01; j>>=1)  {  
      P1 = j;                         
      for (i = 0; i < 10000; i++)  { 
       wait ();                      
      }	   
    }
}

/* LED ��Ĺ����� */
CTOR(LED)
   FUNCTION_SETTING(run, run)
END_CTOR
/* ------------------------------------ */
CLASS(Controller)
{
    void (*doing)();
};

static void doing()
{
   	LED *pl = LEDNew();
     while (1) {  
	   pl->run();
	}
}

CTOR(Controller)
   FUNCTION_SETTING(doing, doing);
END_CTOR
/* ------------------------------------ */
/* ������ */
char xdata MemPool[1024];
void main (void)  {
    Controller *pc;	        /* ����LED��̬��ָ�� */
    init_mempool(MemPool,sizeof(MemPool));
    pc = ControllerNew();  
    pc->doing();            /* ���øö����run()���� */
}
