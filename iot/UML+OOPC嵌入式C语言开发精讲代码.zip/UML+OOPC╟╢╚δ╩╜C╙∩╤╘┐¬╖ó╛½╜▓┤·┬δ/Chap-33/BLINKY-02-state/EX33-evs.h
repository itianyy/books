/* EX17-evs.h */
#ifndef EVS_H
#define EVS_H
#include "lw_oopc_kc.h"

INTERFACE(IEvState)
{
    void (*perform)();
};
#endif
