/*  cx14-all.h  */
#ifndef IALL_H
#define IALL_H
#include "cx14-ib.h"
#include "cx14-ic.h"

INTERFACE(IALL)
  {
    IMPLEMENTS(IB);
    IMPLEMENTS(IC);   
  };
#endif
