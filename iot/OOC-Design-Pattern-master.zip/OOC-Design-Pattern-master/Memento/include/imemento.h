#ifndef IMEMENTO_H
#define IMEMENTO_H

typedef struct _IMemento IMemento;

struct _IMemento
{
};

#endif
