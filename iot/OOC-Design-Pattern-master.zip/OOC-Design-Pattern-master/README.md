# OOC-Design-Pattern
Design Pattern by Object-Oriented-C
