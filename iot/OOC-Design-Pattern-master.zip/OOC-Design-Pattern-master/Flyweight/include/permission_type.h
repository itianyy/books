#ifndef PERMISSION_TYPE_H
#define PERMISSION_TYPE_H

typedef enum _PermissionType PermissionType;

enum _PermissionType
{
	Read,
	Write,
	ReadWrite
};

#endif
