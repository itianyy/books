TYS-zh-translation
==================

A Chinese translation of the Well-known Scheme Tutorial: "Teach Yourself Scheme in Fixnum Days"

You can find it here: http://songjinghe.github.io/TYS-zh-translation/

《Teach Yourself Scheme in Fixnum Days》的中文翻译，译者水平有限，如有错误希望大家积极反馈。

## 其他资源(other resources)

日本紫藤貴文(Takafumi Shido)先生《Yet Another Scheme Tutorial（Scheme入门教程）》的中文译文： https://github.com/DeathKing/yast-cn
