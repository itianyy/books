#ifndef _VM_CORE_H
#define _VM_CORE_H
extern char* rootDir;
char* readFile(const char* sourceFile);
#endif
